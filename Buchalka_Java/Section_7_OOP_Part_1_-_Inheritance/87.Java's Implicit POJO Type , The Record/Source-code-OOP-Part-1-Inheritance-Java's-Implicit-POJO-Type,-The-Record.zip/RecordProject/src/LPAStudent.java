public record LPAStudent(String id, String name, String dateOfBirth, String classList) {
}
