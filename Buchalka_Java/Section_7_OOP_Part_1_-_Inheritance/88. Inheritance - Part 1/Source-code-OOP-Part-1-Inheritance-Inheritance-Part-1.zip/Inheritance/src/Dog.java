public class Dog extends Animal {

    public Dog() {
        super("Mutt", "Big", 50);
    }
}
